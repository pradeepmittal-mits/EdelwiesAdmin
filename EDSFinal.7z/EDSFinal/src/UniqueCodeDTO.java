
public class UniqueCodeDTO {

	String uniqueCode;
	String state;
	String entity;
	String city;
	String Region;
	String PropertyAdress;

	public String getPropertyAdress() {
		return PropertyAdress;
	}

	public void setPropertyAdress(String propertyAdress) {
		PropertyAdress = propertyAdress;
	}

	public String getRegion() {
		return Region;
	}

	public void setRegion(String region) {
		Region = region;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUniqueCode() {
		return uniqueCode;
	}

	public void setUniqueCode(String uniqueCode) {
		this.uniqueCode = uniqueCode;
	}

	@Override
	public String toString() {
		return "UniqueCodeDTO [uniqueCode=" + uniqueCode + ", state=" + state + ", entity=" + entity + ",city=" + city
				+ ", getUniqueCode()=" + getUniqueCode() + ", getState()=" + getState() + ", getEntity()=" + getEntity()
				+ ",getCity()=" + getCity() + ",getRegion()=" + getRegion() + ",getPropertyAdress()="
				+ getPropertyAdress() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

}
