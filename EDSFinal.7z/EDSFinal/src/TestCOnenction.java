import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestCOnenction {

	public static void main(String[] args) {
		// String urlPrefix = "jdbc:db2:";

		String url;
		String user;
		String password;
		String state;
		Connection con;
		Statement stmt;
		ResultSet rs;

		System.out.println("**** Enter class EzJava");

		url = "jdbc:db2://172.16.8.75:50000/SAMPLE";
		user = "db2admin";
		password = "mits123$";
		try {

			Class.forName("com.ibm.db2.jcc.DB2Driver");
			System.out.println("**** Loaded the JDBC driver");

			con = DriverManager.getConnection(url, user, password);

			con.setAutoCommit(false);
			System.out.println("**** Created a JDBC connection to the data source");

			stmt = con.createStatement();
			System.out.println("**** Created JDBC Statement object");

			rs = stmt.executeQuery(
					"SELECT UNIQUE_CODE,STATE,ENTITY,REGION,PROPERTY_ADDRESS FROM  ADMINISTRATOR.UNIQUE_CODE");
			System.out.println("**** Created JDBC ResultSet object");

			while (rs.next()) {
				String s = rs.getString(1);
				String s1 = rs.getString(2);
				String s2 = rs.getString(3);
				String s3 = rs.getString(4);

				System.out.println("unique code = " + s);
				System.out.println("state = " + s1);
				System.out.println("entity = " + s2);
				System.out.println("region = " + s3);

			}
			System.out.println("**** Fetched all rows from JDBC ResultSet");

			rs.close();
			System.out.println("**** Closed JDBC ResultSet");

			stmt.close();
			System.out.println("**** Closed JDBC Statement");

			con.commit();
			System.out.println("**** Transaction committed");

			con.close();
			System.out.println("**** Disconnected from data source");

			System.out.println("**** JDBC Exit from class EzJava - no errors");

		}

		catch (ClassNotFoundException e) {
			System.err.println("Could not load JDBC driver");
			System.out.println("Exception: " + e);
			e.printStackTrace();
		}

		catch (SQLException ex) {
			System.err.println("SQLException information");
			while (ex != null) {
				System.err.println("Error msg: " + ex.getMessage());
				System.err.println("SQLSTATE: " + ex.getSQLState());
				System.err.println("Error code: " + ex.getErrorCode());
				ex.printStackTrace();
				ex = ex.getNextException();
			}
		}
	}
}
