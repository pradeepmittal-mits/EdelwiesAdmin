
public class DocFunctionDTO {

	String functionName;
	String DocType;

	boolean isVendorVisible;

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	@Override
	public String toString() {
		return "DocfunctionDTO [functionName=" + functionName + ", DocType=" + DocType + ", isVendorVisible="
				+ isVendorVisible + "]";
	}

	public String getDocType() {
		return DocType;
	}

	public void setDocType(String docType) {
		DocType = docType;
	}

	public boolean isVendorVisible() {
		return isVendorVisible;
	}

	public void setVendorVisible(boolean isVendorVisible) {
		this.isVendorVisible = isVendorVisible;
	}

}
