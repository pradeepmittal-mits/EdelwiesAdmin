

public class ICNConstants {

	public static final String ICN_PROP_FILE_NAME="DatabaseConfig.properties";
	
	public static final String DATABASESCHEMA="ADMINSTRATOR";
	
	
}
