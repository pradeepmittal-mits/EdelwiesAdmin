
public class FunctionDTO {
	String function;
	String document_type;
	String field_Status;

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getDocument_type() {
		return document_type;
	}

	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}

	public String getField_Status() {
		return field_Status;
	}

	public void setField_Status(String field_Status) {
		this.field_Status = field_Status;
	}

}
